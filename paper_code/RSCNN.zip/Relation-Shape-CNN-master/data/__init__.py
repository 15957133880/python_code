from .ModelNet40Loader import ModelNet40Cls
from .ShapeNetPartLoader import ShapeNetPart