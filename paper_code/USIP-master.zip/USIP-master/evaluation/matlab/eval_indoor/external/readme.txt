This folder contains external scripts:
- Estimate rigid transform: from Babak Taati
- Find Point Normals: Zachary Taylor