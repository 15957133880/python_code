clear all
global maxTrials

maxTrials = 50;
evaluate_oxford;
maxTrials = 100;
evaluate_oxford;
maxTrials = 250;
evaluate_oxford;
maxTrials = 500;
evaluate_oxford;
maxTrials = 1000;
evaluate_oxford;
maxTrials = 2500;
evaluate_oxford;
maxTrials = 5000;
evaluate_oxford;
maxTrials = 10000;
evaluate_oxford;