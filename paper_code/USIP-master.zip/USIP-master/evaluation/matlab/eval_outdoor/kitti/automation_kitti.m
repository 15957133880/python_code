clear all
global maxTrials

maxTrials = 50;
evaluate_kitti;
maxTrials = 100;
evaluate_kitti;
maxTrials = 250;
evaluate_kitti;
maxTrials = 500;
evaluate_kitti;
maxTrials = 1000;
evaluate_kitti;
maxTrials = 2500;
evaluate_kitti;
maxTrials = 5000;
evaluate_kitti;
maxTrials = 10000;
evaluate_kitti;