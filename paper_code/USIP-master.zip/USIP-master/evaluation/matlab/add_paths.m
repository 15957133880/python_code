clear all;
close all;

addpath(genpath('tools'));
addpath(genpath('eval_indoor'));
addpath(genpath('eval_outdoor'));
addpath(genpath('eval_repeatability'));